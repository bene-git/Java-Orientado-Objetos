/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

/**
 *
 * @author STI
 */
public class UsaEstoque06 {
    public static void mainTest(){
        Estoque e1 = new Estoque("Cabo de Rede", 100, 15);
        System.out.println("----- Criei uma instância de Estoque ------");
        e1.mostrar();
        System.out.println("\n--------- Dar Baixa - Tentativa 01 --------");
        e1.darBaixa(130);
        System.out.println("--------- Dar Baixa - Tentativa 02 --------");
        e1.darBaixa(90);
        System.out.println("\n----------- Mostrando Novamente -----------");
        e1.mostrar();
        e1.mudarQtdMinima(20);
        e1.mudarNome("Cabo de Rede - UTP");
        System.out.println("\n-- Mudei Quant. Minima e Nome do Estoque --");
        System.out.println("----------- Mostrando Novamente -----------");
        e1.mostrar();
        System.out.println("\n------------ Fiz Uma Reposição ------------");
        e1.repor(120);
        System.out.println("\n----------- Mostrando Novamente -----------");
        e1.mostrar();
    }
}
