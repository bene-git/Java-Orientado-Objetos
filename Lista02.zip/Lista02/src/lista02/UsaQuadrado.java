/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

/**
 *
 * @author STI
 */
public class UsaQuadrado {
    public static void maintest (){
        Quadrado q1 = new Quadrado(2.0);
        Quadrado q2 = new Quadrado(4.0);
        Quadrado q3 = new Quadrado(5.0);
        
        System.out.println("---- Quadrado 01 ----");
        System.out.println("Area      = "+q1.area(2.0));
        System.out.println("Perimetro = "+q1.perimetro(2.0));
        System.out.println("---- Quadrado 02 ----");
        System.out.println("Area      = "+q2.area(4.0));
        System.out.println("Perimetro = "+q2.perimetro(4.0));
        System.out.println("---- Quadrado 03 ----");
        System.out.println("Area      = "+q3.area(5.0));
        System.out.println("Perimetro = "+q3.perimetro(5.0));
    }
}
