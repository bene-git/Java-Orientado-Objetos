/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

/**
 *
 * @author STI
 */
public class Quadrado {
    
    Double lado;
    
    public Quadrado(Double umLado){
        this.lado = umLado;
    }
    
    Double area (Double lado){
        return lado*lado;
    }
    
    Double perimetro (Double lado){
        return lado * 4;
    }
    
}
