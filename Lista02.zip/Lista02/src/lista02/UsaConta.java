/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

/**
 *
 * @author STI
 */
public class UsaConta {
    public static void mainTest(){
        System.out.println("--- Criei Duas Instancias de Conta ---");
        System.out.println("----- Mostrando Contas Cadastradas -----");
        Conta c1 = new Conta("Benedito Rodrigo", 1234, "AB18", "02/09/2018");
        Conta c2 = new Conta("Alcemir Santos", 1357, "AC21", "03/09/2018");
        c1.recuperaDadosParaImpressao();
        System.out.println("");
        c2.recuperaDadosParaImpressao();
        System.out.println("\n------ Realizei Deposito nas Contas ------");
        System.out.println("--------------- Conta 01 ---------------");
        c1.depositar(1000.0);
        System.out.println("\n--------------- Conta 02 ---------------");
        c2.depositar(10000.50);
        System.out.println("\n----- Mostrando Informações Novamente -----");
        c1.recuperaDadosParaImpressao();
        System.out.println("");
        c2.recuperaDadosParaImpressao();
        System.out.println("\n------- Tentei Realizar Saques Nas Contas ------");
        System.out.println("--------------- Conta 01 ---------------");
        c1.sacar(100000.50);
        System.out.println("\n--------------- Conta 02 ---------------");
        c2.sacar(1254.50);
        System.out.println("\n----- Mostrando Informações Novamente -----");
        c1.recuperaDadosParaImpressao();
        System.out.println("");
        c2.recuperaDadosParaImpressao();
    }
}
