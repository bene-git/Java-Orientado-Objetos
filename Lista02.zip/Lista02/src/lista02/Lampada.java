/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

/**
 *
 * @author STI
 */
public class Lampada {
    boolean ligada;
    
    void liga(){
        this.ligada = true;
    }
    
    void desliga(){
        this.ligada = false;
    }
    
    void observa(boolean lampada){
        if(lampada==true)
            System.out.println("Ligada");
        else
            System.out.println("Desligada");
    }
    
}
