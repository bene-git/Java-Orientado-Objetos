/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

/**
 *
 * @author STI
 */
public class Conta {
    String nome;
    Integer numConta;
    String agencia;
    Double saldo = 0.0;
    String data;
    
    public Conta(String umNome, Integer umaCont, String umaAgencia, String umaData){
        this.nome = umNome;
        this.numConta = umaCont;
        this.agencia = umaAgencia;
        this.data = umaData;
    }
    
    public void sacar(Double sac){
        System.out.println("Client: "+this.nome);
        System.out.println("Conta:  "+this.numConta);
        if(sac>this.saldo){
            System.out.println("Saldo Insuficiente em "+this.numConta);
        } else {
            saldo -= sac;
            System.out.println("Saque Realizado.");
            System.out.println("Novo Saldo = "+this.saldo);
        }
    }
    
    public void depositar(Double dep){
        System.out.println("Client: "+this.nome);
        System.out.println("Conta:  "+this.numConta);
        saldo += dep;
        System.out.println("Deposito Realizado em "+this.numConta);
        System.out.println("Novo Saldo de "+this.numConta+" = "+this.saldo);
    }
    
    public Double calcRend(Double valor){
        return valor*0.1;
    }
    
    public void recuperaDadosParaImpressao(){
        System.out.println("Nome Client = "+this.nome);
        System.out.println("Numer Conta = "+this.numConta);
        System.out.println("Agenc Conta = "+this.agencia);
        System.out.println("Saldo Atual = "+this.saldo+" R$");
        System.out.printf("Rendimento  = %.2f R$\n", this.saldo*0.1);
        System.out.println("Data Abert. = "+this.data);
    }
}
