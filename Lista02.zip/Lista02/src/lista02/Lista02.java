/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

import java.util.Scanner;

/**
 *
 * @author STI
 */
public class Lista02 {
    static Scanner ent = new Scanner(System.in);
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Integer op;
        do{
            System.out.println("\nInforme uma questão para testar:"
                    + "\nQuestões de 1 a 9"
                    + "\nInforme [0] para Sair");
            op = ent.nextInt();
            System.out.println("");
            switch(op){
                case 1:
                    questao01();
                    break;
                case 2:
                    questao02();
                    break;
                case 3:
                    System.out.println("\n03 Implementação do que será testado na 04");
                    break;
                case 4:
                    UsaQuadrado.maintest();
                    break;
                case 5:
                    System.out.println("\n05 Implementação do que será testado na 06");
                    break;
                case 6:
                    UsaEstoque06.mainTest();
                    break;
                case 7:
                    UsaEstoque7.usar();
                    break;
                case 8:
                    System.out.println("\n08 Implementação do que será testado na 09");
                    break;
                case 9:
                    UsaConta.mainTest();
                    break;
                case 0:
                    System.out.println("Finalizando.....");
                    break;
                default:
                    System.out.println("Opção Inválida!");
                    break;
            }
        } while(op!=0);
        /*questao01(); (01) aqui
        questao02(); (02) aqui
        (03) implementa e testa na (04)
        UsaQuadrado.maintest(); (04) aqui
        UsaEstoque06.mainTest();
        UsaEstoque7.usar(); //(07) aqui
        (08) implementa e testa na (09)
        UsaConta.mainTest(); //(09)aqui*/
        
    }
    
    public static void questao01(){
        Lampada lp = new Lampada();
        lp.liga();
        System.out.println("É para estar ligada:");
        lp.observa(lp.ligada);
        lp.desliga();
        System.out.println("É pra estar desligada:");
        lp.observa(lp.ligada);
    }
    
    public static void questao02(){
        Lampada lampa1 = new Lampada();
        Lampada lampa2 = new Lampada();
        lampa1.liga();
        lampa2.desliga();
        System.out.println("--- Lâmpada 01 ---");
        lampa1.observa(lampa1.ligada);
        System.out.println("--- Lâmpada 02 ---");
        lampa2.observa(lampa2.ligada);
    }

    
}
