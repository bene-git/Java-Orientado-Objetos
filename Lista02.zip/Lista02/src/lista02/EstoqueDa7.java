/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

/**
 *
 * @author STI
 */
public class EstoqueDa7 {
    String nome;
    Integer qtda;
    Integer qtdm;
    
    public EstoqueDa7(String nm, Integer qa, Integer qm){
        this.nome = nm;
        this.qtda = qa;
        this.qtdm = qm;
    }
    
    public void mostrar(){
        System.out.println("Nome do Produto = "+nome);
        System.out.println("Quantidad Atual = "+qtda);
        System.out.println("Quantid. Minima = "+qtdm);
    }
    
    public void darBaixa(int n){
        qtda -= n;
    }
    
    public void repor(int n){
        qtda += n;
    }
    
    public boolean precisarepor(){
        if(this.qtda<this.qtdm)
            return true;
        else
            return false;
    }
}
