/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

/**
 *
 * @author STI
 */
public class Estoque {
    
    String nome;
    Integer qtdAtual;
    Integer qtdMinima;
    
    public Estoque(String umNome, Integer umaQtdAtual, Integer umaQtdMin){
        this.nome = umNome;
        this.qtdAtual = umaQtdAtual;
        this.qtdMinima = umaQtdMin;
    }
    
    public void mudarNome(String umNome){
        this.nome = umNome;
    }
    
    public void mudarQtdMinima(Integer qtm){
        if(qtm<0){
            System.out.println("Quant. Minima Invalida!");
        } else {
            this.qtdMinima = qtm;
            System.out.println("Quant. Minima Atualizada para "+this.qtdMinima);
        }
    }
    
    public void repor(Integer rep){
        if(rep<1){
            System.out.println("Reposição Inválida!");
        } else {
            this.qtdAtual = rep;
            System.out.println("Reposição Realizada!");
            System.out.println("Nova Quant. Atual = "+this.qtdAtual);
        }
    }
    
    public void darBaixa(Integer ret){
        if(ret>this.qtdAtual){
            System.out.println("Retirada Inválida!");
        } else{
            this.qtdAtual -= ret;
            System.out.println("Retirada Realizada!");
            System.out.println("Nova Quant. Atual = "+this.qtdAtual);
        }
    }
    
    public void mostrar(){
        System.out.println("Nome do Estoque  = "+this.nome);
        System.out.println("Quant. Atual Est = "+this.qtdAtual);
        System.out.println("Quant. Minim Est = "+this.qtdMinima);
        System.out.println("Precisa Repor    = "+precisarepor(this.qtdAtual,this.qtdMinima));
    }
    
    public boolean precisarepor(Integer n, Integer n2){
        if(n<n2)
            return true;
        else
            return false;
    }
    
}
