/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lista02;

/**
 *
 * @author STI
 */
public class UsaEstoque7 {
    public static void usar(){
        EstoqueDa7 est1 = new EstoqueDa7("Impressora", 13, 6);
        EstoqueDa7 est2 = new EstoqueDa7("Monitor", 11, 13);
        EstoqueDa7 est3 = new EstoqueDa7("Mouse", 6, 2);
        System.out.println("----- Estoque 1 -----");
        est1.mostrar();
        System.out.println("----- Estoque 2 -----");
        est2.mostrar();
        System.out.println("----- Estoque 3 -----");
        est3.mostrar();
        System.out.println("\n- Deu baixa em 5 itens do Estoque 1");
        System.out.println("- Reposição em 7 itens  o Estoque 2");
        System.out.println("- Deu baixa em 4 itens do Estoque 3");
        est1.darBaixa(5);
        est2.repor(7);
        est3.darBaixa(4);
        System.out.println("\nVerifica se os Estoques precisam repor:");
        System.out.println("Estoque 1 = "+est1.precisarepor());
        System.out.println("Estoque 2 = "+est2.precisarepor());
        System.out.println("Estoque 3 = "+est3.precisarepor());
        System.out.println("\n--- Mostrando apos as alterações ---");
        System.out.println("----- Estoque 1 -----");
        est1.mostrar();
        System.out.println("----- Estoque 2 -----");
        est2.mostrar();
        System.out.println("----- Estoque 3 -----");
        est3.mostrar();
    }
}
